/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 20 2015 09:36:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Tue Jan 20 10:01:01 2015
  */

#include "rocs/public/dir.h"


static const char* name = "ODir";

typedef struct ODirData {

    /** Path pointing to the directory. */
  char* path;
    /** Last error. */
  int rc;
    /** Directory structure as defined in dirent.h. */
  DIR* dir;

} *iODirData;

static iODirData Data( void* p ) { return (iODirData)((iODir)p)->base.data; }


/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Thread
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/thread_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOThreadData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OThread ----- */


/** Find a thread by name. */
static struct OThread* _find( const char* name ) {
  return 0;
}


/** Find a thread by id. */
static struct OThread* _findById( unsigned long id ) {
  return 0;
}


/** Get a list of all threads. */
static iOList _getAll( void ) {
  return 0;
}


/** Thread name. */
static const char* _getName( struct OThread* inst ) {
  return 0;
}


/** Get parameter object. */
static void* _getParm( struct OThread* inst ) {
  return 0;
}


/** Get post from the queue. (NULL if nothing is in queue.) */
static obj _getPost( struct OThread* inst ) {
  return 0;
}


/** Get current thread id. */
static unsigned long _id( void ) {
  return 0;
}


/** Object creator. */
static struct OThread* _inst( const char* name ,thread_run run ,void* parm ) {
  iOThread __Thread = allocMem( sizeof( struct OThread ) );
  iOThreadData data = allocMem( sizeof( struct OThreadData ) );
  MemOp.basecpy( __Thread, &ThreadOp, 0, sizeof( struct OThread ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Thread;
}


/** Pause signaled. */
static Boolean _isPause( struct OThread* inst ) {
  return 0;
}


/** Quit signaled. */
static Boolean _isQuit( struct OThread* inst ) {
  return 0;
}


/** Waits for thread termination and returns True if ok. */
static Boolean _join( struct OThread* inst ) {
  return 0;
}


/** Kill a thread by reference. */
static void _kill( struct OThread* inst ) {
  return;
}


/** set pause flag */
static void _pause( struct OThread* inst ,Boolean pause ) {
  return;
}


/** Post a message into the queue. */
static Boolean _post( struct OThread* inst ,obj msg ) {
  return 0;
}


/** Post a message into the queue. */
static Boolean _prioPost( struct OThread* inst ,obj msg ,int prio ) {
  return 0;
}


/** Signals thread to stop as soon as possible. */
static void _requestQuit( struct OThread* inst ) {
  return;
}


/** Signals all thread to stop as soon as possible. */
static void _requestQuitAll( void ) {
  return;
}


/**  */
static void _setDescription( struct OThread* inst ,const char* desc ) {
  return;
}


/** Sets the priority to high. */
static void _setHigh( struct OThread* inst ) {
  return;
}


/** Change the default stacksize. */
static void _setStacksize( struct OThread* inst ,long size ) {
  return;
}


/** Sleeps the current thread. */
static void _sleep( int time ) {
  return;
}


/** Starts the thread runner. */
static Boolean _start( struct OThread* inst ) {
  return 0;
}


/** Get post from the queue. (Wait until post comes in queue.) */
static obj _waitPost( struct OThread* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/thread.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/

/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Str
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/str_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OStr ----- */


/** Converts binary data into a hex string like 0AFE... */
static char* _byteToStr( unsigned char* bin ,int len ) {
  return 0;
}


/**  */
static char* _cat( char* dest ,const char* src ) {
  return 0;
}


/**  */
static char* _catID( char* dest ,const char* src ,RocsMemID id ) {
  return 0;
}


/** Copies a string. */
static char* _copy( char* dst ,const char* src ) {
  return 0;
}


/** Copies a zero terminated string as a non-zero terminated string. */
static int _copynz( char* snz ,int snzlen ,const char* str ) {
  return 0;
}


/** Creates a timestamp: YYYYmmdd.hhMMss.SSS. */
static char* _createStamp( void ) {
  return 0;
}


/** Creates a timestamp: YYYYmmdd.hhMMss.SSS. */
static char* _createStampID( RocsMemID id ) {
  return 0;
}


/** Creates a timestamp: YYYYmmddhhMMssSSS. */
static char* _createStampNoDots( void ) {
  return 0;
}


/** replace url escapes with special chars */
static char* _decode4URL( const char* url ) {
  return 0;
}


/** Duplicates a string. */
static char* _dup( const char* src ) {
  return 0;
}


/** Duplicates a string. */
static char* _dupID( const char* src ,RocsMemID id ) {
  return 0;
}


/** replace special chars with url escapes */
static char* _encode4URL( const char* url ) {
  return 0;
}


/** Check if str1 ends with str2. */
static Boolean _endsWith( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Check if str1 ends with str2. (ignoring case) */
static Boolean _endsWithi( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Compares two strings. */
static Boolean _equals( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Equals ignore case. */
static Boolean _equalsi( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Equals till number off char is reached. */
static Boolean _equalsn( const char* str1 ,const char* str2 ,int cnt ) {
  return 0;
}


/** Equals ignore case till number off char is reached. */
static Boolean _equalsni( const char* str1 ,const char* str2 ,int cnt ) {
  return 0;
}


/** Finds a substring. */
static char* _find( const char* str ,const char* substr ) {
  return 0;
}


/** Find the first occurrence of a character. */
static char* _findc( const char* str ,char c ) {
  return 0;
}


/** Finds a substring ignoring case. */
static char* _findi( const char* str ,const char* substr ) {
  return 0;
}


/** Formats a string. */
static char* _fmt( const char* format ,...  ) {
  return 0;
}


/** Formats a string. */
static char* _fmtID( RocsMemID id ,const char* format ,...  ) {
  return 0;
}


/** Formats a string into a buffer. */
static char* _fmtb( char* buffer ,const char* format ,...  ) {
  return 0;
}


/** Free up a string allocation. */
static void _free( char* str ) {
  return;
}


/** Free up a string allocation. */
static void _freeID( char* str ,RocsMemID id ) {
  return;
}


/** Returns number of linefeed chars found. */
static int _getCntLinefeeds( const char* str ) {
  return 0;
}


/** Returns a pointer to the string extension: [readme.txt] would return a pointer to [txt]. */
static char* _getExtension( const char* str ) {
  return 0;
}


/** Returns pointer to the specified line. */
static char* _getLine( const char* str ,int nr ) {
  return 0;
}


/** Returns pointer to the specified line. */
static char* _getLineID( const char* str ,int nr ,RocsMemID id ) {
  return 0;
}


/** Returns pointer to the next line. */
static char* _getNextLine( const char* str ,int* nr ) {
  return 0;
}


/** Converts an integer into a non-zero string. */
static void _int2snz( char* snz ,int snzlen ,int val ) {
  return;
}


/** Creates an ISO date string: YYYY-mm-dd */
static char* _isoDate( long tt ) {
  return 0;
}


/** Creates an ISO time string: hh:MM:ss */
static char* _isoTime( long tt ) {
  return 0;
}


/** Calculates the string length. */
static int _len( const char* str ) {
  return 0;
}


/** Converts an long into a non-zero string. */
static void _long2snz( char* snz ,int snzlen ,long val ) {
  return;
}


/** Replace all charA's with charB */
static int _replaceAll( char* str ,char charA ,char charB ) {
  return 0;
}


/** Replace all substrings with the replacement. */
static char* _replaceAllSub( const char* inputString ,const char* substring ,const char* replacement ) {
  return 0;
}


/** Replace all environment variables with there current values. */
static char* _replaceAllSubstitutions( const char* str ) {
  return 0;
}


/** Converts an non-zero string as a zero terminated string. */
static char* _snz2sz( const char* snz ,int snzlen ) {
  return 0;
}


/** Converts an non-zero string as a zero terminated string. */
static char* _snz2szID( const char* snz ,int snzlen ,RocsMemID id ) {
  return 0;
}


/** Check if str1 starts with str2. */
static Boolean _startsWith( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Check if str1 starts with str2. (ignoring case) */
static Boolean _startsWithi( const char* str1 ,const char* str2 ) {
  return 0;
}


/** Converts a hex string into binary data */
static unsigned char* _strToByte( const char* str ) {
  return 0;
}


/** Converts all chars into lowercase. */
static const char* _strlwr( const char* str ) {
  return 0;
}


/** Converts all chars into uppercase. */
static const char* _strupr( const char* str ) {
  return 0;
}


/** Removes leading and trailing blanks. */
static char* _trim( char* str ) {
  return 0;
}


/** Removes trailing blanks. */
static char* _trimID( char* str ,RocsMemID id ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/str.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/

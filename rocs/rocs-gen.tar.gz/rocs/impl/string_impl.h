/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 20 2015 09:36:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Tue Jan 20 10:01:01 2015
  */

#include "rocs/public/string.h"


static const char* name = "OString";

/*  */
#define STRING_MINSIZE 80
typedef struct OStringData {

    /** String value. */
  char* str;
    /** String length. */
  int len;

} *iOStringData;

static iOStringData Data( void* p ) { return (iOStringData)((iOString)p)->base.data; }


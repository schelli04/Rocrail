/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Apr 10 2013 08:20:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Doc
  * Date: Thu Apr 11 06:52:07 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/doc_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iODocData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- ODoc ----- */


/** Search for a given attribute in the given node. */
static Boolean _getBool( struct ODoc* inst ,const char* nodename ,const char* attrname ,Boolean defval ) {
  return 0;
}


/** Document node keeps all 1st level nodes. */
static iONode _getDocNode( struct ODoc* inst ) {
  return 0;
}


/** Get XML encoding for serialize. */
static const char* _getEncoding( void ) {
  return 0;
}


/** Get XML encoding as a property: <?xml encoding="UTF-8"?> */
static char* _getEncodingProperty( void ) {
  return 0;
}


/** Search for a given attribute in the given node. */
static int _getInt( struct ODoc* inst ,const char* nodename ,const char* attrname ,int defval ) {
  return 0;
}


/** This is probably what you want. */
static iONode _getRootNode( struct ODoc* inst ) {
  return 0;
}


/** Search for a given attribute in the given node. */
static const char* _getStr( struct ODoc* inst ,const char* nodename ,const char* attrname ,const char* defval ) {
  return 0;
}


/** Is HTML escapes set. */
static Boolean _isHTMLEscapes( void ) {
  return 0;
}


/** Ignoring case in node and attribute names. */
static Boolean _isIgnoreCase( void ) {
  return 0;
}


/** Is UTF-8 decoded to Latin. */
static Boolean _isUTF2Latin( void ) {
  return 0;
}


/** Is XML UTF-8 encoded. */
static Boolean _isUTF8Encoded( struct ODoc* inst ) {
  return 0;
}


/** UTF-8 encoding for serializing. */
static Boolean _isUTF8Encoding( void ) {
  return 0;
}


/** Is UniCode escapes set. */
static Boolean _isUniCodeEscapes( void ) {
  return 0;
}


/** Represents a node recursive as string. */
static char* _node2String( iONode node ,Boolean escaped ) {
  return 0;
}


/** Parses given buffer. */
static struct ODoc* _parse( const char* xml ) {
  return 0;
}


/** Set XML encoding for serialize. */
static void _setEncoding( const char* enc ) {
  return;
}


/** Set HTML escapes. */
static void _setHTMLEscapes( Boolean html ) {
  return;
}


/** Ignoring case in node and attribute names. */
static void _setIgnoreCase( Boolean ignore ) {
  return;
}


/** Is UTF-8 decoded to Latin. */
static void _setUTF2Latin( Boolean decode ) {
  return;
}


/** Set UniCode escapes. */
static void _setUniCodeEscapes( Boolean uni ) {
  return;
}


/** Add XML Prolog. */
static void _setXMLProlog( Boolean prolog ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/doc.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/

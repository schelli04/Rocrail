/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan  8 2015 16:22:30)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Jan  8 16:51:29 2015
  */

#include "rocs/public/gzip.h"


static const char* name = "OGZip";

typedef struct OGZipData {

    /**  */
  char* name;
    /**  */
  int rc;

} *iOGZipData;

static iOGZipData Data( void* p ) { return (iOGZipData)((iOGZip)p)->base.data; }

